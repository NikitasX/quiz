<?php 
// see sample-data.txt on what to return

$projects = array (
	1 => array (
		"name" => "Wordpress",
		"user" => 1
	),
	2 => array (
		"name" => "Blog",
		"user" => 1
	),
	3 => array (
		"name" => "Wiki",
		"user" => 2
	),
	4 => array (
		"name" => "Magento",
		"user" => 3
	),
	5 => array (
		"name" => "Codeigniter",
		"user" => 1
	),
	6 => array (
		"name" => "Slim",
		"user" => 3
	),
	7 => array (
		"name" => "Laravel",
		"user" => 2
	),
	8 => array (
		"name" => "Drupal",
		"user" => 1
	),
	9 => array (
		"name" => "Joomla",
		"user" => 4
	)
);

return $projects;