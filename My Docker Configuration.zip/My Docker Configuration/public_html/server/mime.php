<?php
// Set `MIME type` to JSON
// Edit file below this line
// Add only 1 line

header('Content-Type: application/json');

// Set any other `header` that will help the script to be executed normally if needed
// Edit file below this line
// Add as many line as needed
