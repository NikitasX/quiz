<?php
// see sample-data.txt on what to return

$users = array (
	1 => array (
		"id" => 1,
		"name" => "John",
		"lastName" => "Doe"
	),
	2 => array (
		"id" => 2,
		"name" => "Chris",
		"lastName" => "Black"
	),
	3 => array (
		"id" => 3,
		"name" => "George",
		"lastName" => "Best"
	)
);

return $users;