<?php 

//phpinfo();

echo 'hello';
?>